package com.example.happyhouse.model;

public class BusDto {
	String id;
	String ARS_ID;
	String station;
	String lng;
	String lat;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getARS_ID() {
		return ARS_ID;
	}
	public void setARS_ID(String aRS_ID) {
		ARS_ID = aRS_ID;
	}
	public String getStation() {
		return station;
	}
	public void setStation(String station) {
		this.station = station;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	
}
