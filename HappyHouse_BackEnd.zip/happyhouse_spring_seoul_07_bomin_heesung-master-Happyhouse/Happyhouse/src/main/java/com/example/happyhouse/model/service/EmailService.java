package com.example.happyhouse.model.service;

public interface EmailService {
	public void sendSimpleMessage(String to) throws Exception;
}
