package com.example.happyhouse.model;

public class BicycleDto {
	String id;
	String place;
	String gugunname;
	String placedetail;
	String lat;
	String lng;
	String maxcount;
	String btype;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getGugunname() {
		return gugunname;
	}
	public void setGugunname(String gugunname) {
		this.gugunname = gugunname;
	}
	public String getPlacedetail() {
		return placedetail;
	}
	public void setPlacedetail(String placedetail) {
		this.placedetail = placedetail;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	public String getMaxcount() {
		return maxcount;
	}
	public void setMaxcount(String maxcount) {
		this.maxcount = maxcount;
	}
	public String getBtype() {
		return btype;
	}
	public void setBtype(String btype) {
		this.btype = btype;
	}
	
}
