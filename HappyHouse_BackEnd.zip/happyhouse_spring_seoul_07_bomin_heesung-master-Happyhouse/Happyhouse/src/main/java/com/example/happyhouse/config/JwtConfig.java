package com.example.happyhouse.config;

public class JwtConfig {

}
