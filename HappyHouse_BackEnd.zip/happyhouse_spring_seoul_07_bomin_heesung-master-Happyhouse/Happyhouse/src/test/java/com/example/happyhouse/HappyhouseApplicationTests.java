package com.example.happyhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappyhouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
