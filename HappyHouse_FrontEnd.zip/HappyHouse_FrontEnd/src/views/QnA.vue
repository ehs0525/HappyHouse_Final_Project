<template>
  <div class="container mx-auto">
    <router-view></router-view>
  </div>

  <!-- <div class="container mx-auto sm:flex py-5 sm:py-10 mt-10 sm:mt-20">
    <router-view></router-view>
  </div> -->
</template>

<script>
export default {};
</script>

<style></style>
