// import { apiInstance } from "./index.js";

// const api = apiInstance();

// async function registerNotice(notice) {
//   await api.post(`/notice`, JSON.stringify(notice));
// }

// async function deleteInterest(dongcode, memberid, success, fail) {
//   await api
//     .delete(`/member/${dongcode}/${memberid}`)
//     .then(success)
//     .catch(fail);
// }

// async function modifyMemberInfo(member) {
//   await api.put(`/member`, JSON.stringify(member));
// }

// export { registerNotice, deleteInterest };
