<template>
  <qn-a-create-form></qn-a-create-form>
</template>

<script>
import QnACreateForm from "@/components/qna/child/QnACreateForm.vue";

export default {
  components: { QnACreateForm },
};
</script>

<style></style>
