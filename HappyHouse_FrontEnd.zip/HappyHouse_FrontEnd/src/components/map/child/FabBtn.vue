<template>
  <div>
    <vs-button radius color="primary" type="border" icon="search"></vs-button>
    <vs-button radius color="warning" type="filled" icon="public"></vs-button>
    <vs-button
      radius
      color="success"
      type="flat"
      icon="photo_camera"
    ></vs-button>
    <vs-button radius color="dark" type="line" icon="event_note"></vs-button>
    <vs-button
      radius
      color="danger"
      type="gradient"
      icon="person_add"
    ></vs-button>
    <vs-button
      disabled
      radius
      color="primary"
      type="border"
      icon="search"
    ></vs-button>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
