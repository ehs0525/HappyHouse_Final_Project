<template>
  <div>
    <canvas id="planet-chart" style="height:300px;"></canvas>
  </div>
</template>

<script>
import Chart from "chart.js/auto";
import planetChartData from "@/assets/js/chart-data.js";

export default {
  name: "BarChart",
  data() {
    return {
      planetChartData: planetChartData,
    };
  },
  methods: {
    createBarChart(charId, chartData) {
      const ctx = document.getElementById(charId);
      new Chart(ctx, {
        type: chartData.type,
        data: chartData.data,
        options: chartData.options,
      });
    },
  },
  mounted() {
    this.createBarChart("planet-chart", this.planetChartData);
  },
};
</script>
