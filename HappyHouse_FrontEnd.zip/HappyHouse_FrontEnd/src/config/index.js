const API_BASE_URL = "http://localhost:8080/happyhouse";

export { API_BASE_URL };
